/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accesoDatos;

import java.util.ArrayList;

/**
 *
 * @author manolo
 */
public class AccesoDatos {
    // Estructura de datos donde se almacena la información,
    // podría ser una base de datos, fichero o ArrayList.
    ArrayList<Contacto> bbdd = new ArrayList<>();
    Utilidades generar = new Utilidades();
    static int id = 1001;
    
    //RELLENA el array list cpm cpbetos contacto de forma aleatoria
    public boolean generarContactos(int numElementos){
        for (int i = 0; i < numElementos; i++){
            
            Contacto tmp = new Contacto();

            tmp.setNombre(generar.nombres());
            tmp.setApellidos(generar.apellidos());
            tmp.setDni(generar.generarDni());
            tmp.setId(id);
            
            String email = tmp.getNombre() + tmp.getId();
            tmp.setEmail(email+generar.email());
            tmp.setDireccion(generar.direccion());
            tmp.setFechaNac(generar.fechaNac());
            bbdd.add(tmp);
            id++;
        }
        
        return true;
    }
    
    public Contacto getContacto(int posicion){
        return bbdd.get(posicion);
    }
    public int arrayTam(){
        return bbdd.size();
    }
    
    // AÑADIR CONTACTO A LA BBDD
    public Contacto añadirContacto (String nombre, String apellidos, String dni, String email, String direccion, String fechaNac){
            Contacto tmp = new Contacto();
            
            int id;

            tmp.setNombre(nombre);
            tmp.setApellidos(apellidos);
            tmp.setEmail(email);
            tmp.setDni(dni);
            tmp.setDireccion(direccion);
            tmp.setFechaNac(fechaNac);
            id = bbdd.size();
            tmp.setId(id+1001);
            bbdd.add(tmp);
        return tmp;
    }

    public void borrarPos(int posicion){
        bbdd.remove(posicion);
    }
    
}
