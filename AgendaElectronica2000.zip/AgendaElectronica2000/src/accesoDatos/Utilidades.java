/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accesoDatos;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author dam11
 */
public class Utilidades {
    public String generarDni(){
        int dni2 = ThreadLocalRandom.current().nextInt(1000000, 99999999);
        String dni = Integer.toString(dni2);
            
        String juegoCaracteres="TRWAGMYFPDXBNJZSQVHLCKE";
        int modulo= dni2 % 23;
        char letra = juegoCaracteres.charAt(modulo);
            
        if (dni2 < 10000000){
            dni = "0" + dni;
        }
        String dnib = dni + letra;
        return dnib;
    }
    public String nombres(){
        String [] nombres = {"Pedro", "AArón", "Álvaro", "María", "Jorge", "Iván", "Carolina", "Lola", "Claudia", "Raquel", "Ramón", "Tomás", "Marta", "Carmen"};
        return nombres[(int)(Math.random()*14)];
    }
    public String apellidos(){
        String [] apellidos = {"Izquierdo", "Muñoz", "García", "Castellanos", "Morales"};
        return apellidos[(int)(Math.random()*4)];
    }
    public String direccion(){
        String [] direccion = {"TOMELLOSO", "ALCARAZ", "BALLESTERO", "ALAVA", "ALCÁZAR DE SAN JUAN"};
        return direccion[(int)(Math.random()*5)];
    }
    public String fechaNac(){
        String [] fechaNac = {"27/03/1998", "16/04/1997", "09/10/2001", "19/11/2000"};
        return fechaNac[(int)(Math.random()*4)];
    }
    public String email(){
        String [] email = {"@gmail.com", "@yahoo.com", "@hotmail.com", "@bing.es"};
        return email[(int)(Math.random()*4)];
    }
}