/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accesoDatos;

import java.util.concurrent.ThreadLocalRandom;


/**
 * 
 * @author manolo
 */
public class Contacto {

    private int id;
    private String nombre;
    private String apellidos;
    private String dni;
    private String email;
    private String direccion;
    private String fechaNac;


    public Contacto(){    
    }
    
    public Contacto(int id, String nombre, String apellidos, String dni, String email, String direccion, String fechaNac){
        this.id = id;
        this.nombre= nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.direccion = direccion;
        this.fechaNac = fechaNac;  
        this.email = email;
        
    }
    
    @Override
    public String toString() {
        return "Contacto {" + "id = " + id + ", nombre = " + nombre + ", apellidos = " + apellidos + ", dni = " + dni + ", email = " + email + ", direccion = " + direccion + ", fechaNac = " + fechaNac + '}';
    }
    
    public  int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    
}
