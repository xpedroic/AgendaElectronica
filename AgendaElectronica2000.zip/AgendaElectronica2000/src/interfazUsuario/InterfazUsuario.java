/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazUsuario;
import accesoDatos.Contacto;
import java.util.Scanner;
import logicaNegocio.LogicaNegocio;
/**
 *
 * @author manolo
 */
public class InterfazUsuario {
    //LogicaNegocio ln = new LogicaNegocio();
    
    public static void main(String[] args){
        LogicaNegocio ln = new LogicaNegocio();
        Contacto tmp = new Contacto();
        Scanner scan = new Scanner(System.in);
        
        int numContactos;
        

    }   
}
