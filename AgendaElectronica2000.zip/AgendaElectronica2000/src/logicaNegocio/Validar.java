/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaNegocio;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author dam11
 */
public class Validar {
    public boolean validarEmail (String email){
        Pattern pattern = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

        Matcher mather = pattern.matcher(email);
 
        return mather.find() == true;
    }
    public boolean validarEntrada (String nombre, String apellidos, String dni, String email, String direccion, String fechaNac){
        return nombre.equals("") || apellidos.equals("") || dni.equals("") || email.equals("") || direccion.equals("") || fechaNac.equals("") ||
                nombre.equals(" ") || apellidos.equals(" ") || dni.equals(" ") || email.equals(" ") || direccion.equals(" ") || fechaNac.equals(" ");
    }
    
    public boolean validarEntradaCadena (String cadena){
        return cadena.equals("") || cadena.equals(" ");
    }
    
    public boolean validarDni(String dni){
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        String tmp="";
        boolean valida = false;
        int contador=0;
        while (tmp.length()<dni.length()-1){
            tmp = tmp + dni.charAt(contador);
            contador++;
        }
        int num = Integer.parseInt(tmp);
        int numLetra = num % 23;
        if ((letras.charAt(numLetra)== dni.charAt(dni.length()-1))&&(dni.length()==9)){
            valida = true;
        }
        else {
            valida = false;
        }
        return valida;
    }
    public boolean validarFecha (String fecha){
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            formatoFecha.setLenient(false);
            formatoFecha.parse(fecha);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
}
