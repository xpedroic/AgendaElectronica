/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templ hj7ttes
 * and open the template in the editor.
 */
package logicaNegocio;

//import accesoDatos.Contacto;

import accesoDatos.AccesoDatos;
import accesoDatos.Contacto;
import java.util.ArrayList;


/**
 *
 * @author manolo
 */
public class LogicaNegocio {
    AccesoDatos ad = new AccesoDatos();
    
   
    public Contacto getContacto (int posicion){
        return ad.getContacto(posicion);
    }
    
    public boolean generarContacto (int numContactos){
        return ad.generarContactos(numContactos);
    }
    
    public Contacto añadirContacto(String nombre, String apellidos, String dni, String email, String direccion, String fechaNac){
        return ad.añadirContacto(nombre, apellidos, dni, email, direccion, fechaNac);
    }
    
    public boolean borrarContacto(int id){
        Contacto tmp;
        int posicion = 0;
        boolean a=false;
        
        while ((a!=true) && (posicion < ad.arrayTam())){
            tmp = ad.getContacto(posicion);
            if (id==(tmp.getId())){
                ad.borrarPos(posicion);
                a = true;
            }
            posicion++;
        }
        return a;
    }
    public boolean buscarContactoId (int id){
        Contacto tmp;
        int posicion = 0;
        boolean a=false;
        
        while ((a!=true) && (posicion < ad.arrayTam())){
            tmp = ad.getContacto(posicion);
            if (id==(tmp.getId())){
                a = true;
            }
            posicion++;
        }
        return a;
    }
    
    public int arrayTam(){
        return ad.arrayTam();
    }

    public Contacto buscarContactoDni(String dni){
        Contacto tmp;
        int posicion = 0;
        tmp = ad.getContacto(posicion);
        boolean a=false;
        
        while ((a!=true) && (posicion < ad.arrayTam())){
            tmp = ad.getContacto(posicion);
            if (dni.equals(tmp.getDni())){
                a = true;
            }
            posicion++;
        }
        return tmp;
    }
    
    public ArrayList buscarContactoNombre(String nombre){
        Contacto tmp;
        int posicion = 0;
        ArrayList <Contacto> buscarcontact = new ArrayList<>();
        
        while (posicion < ad.arrayTam()){
            tmp = ad.getContacto(posicion);
            if (nombre.equals(tmp.getNombre())){
                buscarcontact.add(tmp);
            }
            posicion++;
        }
        return buscarcontact;
    }
}
